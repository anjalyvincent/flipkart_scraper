from django.contrib.auth.forms import UserCreationForm
from django.views.generic import ListView
from django.views.generic.edit import FormView
from django.contrib.auth import login
from django.shortcuts import render, redirect
from .forms import ScrapedDataForm
from .models import ScrapedProduct


def home(request):
    return render(request,'home.html')

def registration(request):
    return render(request,'registration.html')
    # if request.method =='POST':
    #     form = UserCreationForm(request.POST)
    #     if form.is_valid():
    #         form.save()
    #         return redirect('login')
    # else:
    #     form = UserCreationForm()
    #     return render(request,'registration/register.html',{'form':form})


class ScrapeProductView(FormView):
    template_name = 'scrape_product.html'
    form_class = ScrapedDataForm

    def form_valid(self, form):
        # Perform web scraping here and populate the scraped data
        scraped_data = form.save(commit=False)
        scraped_data.user = self.request.user
        scraped_data.save()
        return redirect('home')  # Redirect to a success page or home

class DisplayScrapedProductsView(ListView):
        template_name = 'display_products.html'
        model = ScrapedProduct
        context_object_name = 'products'



def scrape_url(request):
    if request.method == 'POST':
        form = ScrapedDataForm(request.POST)
        if form.is_valid():
            # Process the form data and save the scraped data to the database
            scraped_data = form.save(commit=False)
            # Perform web scraping here and populate the scraped_data object
            scraped_data.user = request.user  # Associate the logged-in user
            scraped_data.save()
            return redirect('home')  # Redirect after successful form submission
    else:
        form = ScrapedDataForm()

    return render(request, 'scrape_url.html', {'form': form})


def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Log the user in.
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})
def login_view(request):
    return render(request,'scraper_app/login.html')

