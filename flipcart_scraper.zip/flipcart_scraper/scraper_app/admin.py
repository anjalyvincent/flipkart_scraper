from django.contrib import admin
from .models import ScrapedData

admin.site.register(ScrapedData)
