from django.test import TestCase
from django.contrib.auth.models import User
from .models import ScrapedData

class ScrapedDataTestCase(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='testpassword')
        self.scraped_data = ScrapedData.objects.create(
            user=self.user,
            url='https://example.com/product',
            title='Test Product',
            price=99.99,
            reviews=10,
            ratings=4.5,
            media_count=5
        )

    def test_scraped_data_creation(self):
        self.assertEqual(self.scraped_data.user, self.user)
        self.assertEqual(self.scraped_data.url, 'https://example.com/product')
        self.assertEqual(self.scraped_data.title, 'Test Product')
        self.assertEqual(self.scraped_data.price, 99.99)
        self.assertEqual(self.scraped_data.reviews, 10)
        self.assertEqual(self.scraped_data.ratings, 4.5)
        self.assertEqual(self.scraped_data.media_count, 5)

    def test_scraped_data_str(self):
        self.assertEqual(str(self.scraped_data), 'Test Product')
