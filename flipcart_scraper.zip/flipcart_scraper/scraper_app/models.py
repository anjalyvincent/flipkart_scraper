from django.db import models
from django.contrib.auth.models import User
from django import forms
from django.contrib.auth.forms import UserCreationForm

class ScrapedData(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    url = models.URLField()
    title = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField(null=True, blank=True)
    reviews = models.IntegerField()
    ratings = models.FloatField()
    media_count = models.IntegerField()

class ScrapedProduct(models.Model):
        user = models.ForeignKey(User, on_delete=models.CASCADE)
        title = models.CharField(max_length=200)
        price = models.DecimalField(max_digits=10, decimal_places=2)
        description = models.TextField(blank=True, null=True)
        reviews = models.IntegerField()
        ratings = models.FloatField()
        media_count = models.IntegerField()


class CustomUserCreationForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        fields = UserCreationForm.Meta.fields + ('email',)  # Add 'email' field

    def _init_(self, *args, **kwargs):
        super()._init_(*args, **kwargs)
        self.fields['username'].label = 'Username'
        self.fields['email'].label = 'Email'
        # Customize your user creation form if necessary


    def _str_(self):
        return self.title