from django import forms
from .models import ScrapedData

class ScrapedDataForm(forms.ModelForm):
    class Meta:
        model = ScrapedData
        fields = ['title', 'price', 'description', 'reviews', 'ratings', 'media_count']
