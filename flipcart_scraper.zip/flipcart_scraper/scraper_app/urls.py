from django.contrib.auth import views as auth_views
from django.urls import path
from . import views
from .views import ScrapeProductView, DisplayScrapedProductsView

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('signup/', views.signup, name='signup'),
    path('register/', views.registration, name='registration'),
    path('scrape/', ScrapeProductView.as_view(), name='scrape_product'),
    path('display/', DisplayScrapedProductsView.as_view(), name='display_products'),
]